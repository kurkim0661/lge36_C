#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float f = 0.5F;
	unsigned int op = 0x80000000;//���� ��Ʈ�� 1��
	unsigned int *p = (unsigned int)&f;
	int i=0;
	
	for(i=0;i<(sizeof(unsigned int) *8);i))
}

