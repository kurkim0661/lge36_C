#include <stdio.h>
#define FOPEN 1
#define MAX_ROW 100
#define MAX_COL 100
char data[MAX_ROW][MAX_COL];
int gRow;
int gCol;

void printData(char (*m)[MAX_COL], int row, int col);
void getTotal(char (*m)[MAX_COL], int row, int col);
int main() {
	int i;
	int j;
#if defined(FOPEN) && FOPEN ==1
	freopen("data.txt","r",stdin);
#endif
	scanf("%d %d", &gRow,&gCol);
	for(i=0;i<gRow;i++){
		for(j=0;j<gCol;j++){
		scanf(" %c",&data[i][j]);
		}
	}
	
	printData(data,gRow,gCol);
	printf("�� �� : %d ",getTotal(data,gRow,gCol)); 
	return 0;
}

void printData(char (*m)[MAX_COL], int row, int col){
	int i;
	int j;
	
	for(i=0 ; i<row;i++){
		for(j = 0; j<col; j++){
			printf(" %c",m[i][j]);
		}
	}
	printf("\n");
}

int getTotal(char (*d)[MAX_COL], int row, int col){
	int total = 0;
	int ilneTotal;
	int i;
	int j;
	
	for(i=0; i<row; i++){
		lineTotal = 0;
		for(j=0; j<col; j++){
			if(d[i][j] == '1'){
				lineTotal = lineTotal + (1<<col-1-j);
		}
		
		total += lineTotal;
	return total;
