#include <stdio.h>
#include <stdlib.h>
#define SIZE_STR 100
#include <unistd.h>

int main(void) {
	char buffer[SIZE_STR] = {0};
	
#if defined(FOPEN) && (FOPEN ==1)
	freopen("data.txt", "r", stdin);
#endif

//	scanf("%s",buffer);
	fgets(buffer,sizeof(buffer),stdin);
	printf("�о���� ���ڿ� : %s",buffer);
	sleep(1);
	return 0;
}
