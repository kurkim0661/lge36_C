#ifndef UTIL_H_
#define UTIL_H_

#define MAX 100
int swap(int *x, int *y);
extern int a;

#endif
