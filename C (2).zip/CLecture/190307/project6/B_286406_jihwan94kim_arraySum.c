#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ROW 3
#define COL 4

void initArray(int array[][COL]);
void arrayPrint(int array[][COL]);
int main() {
	
	int ary[ROW][COL];
	initArray(ary);	
	arrayPrint(ary);
	
	return 0;
}

void initArray(int array[][COL]){
	srand(time(NULL));
	for(int i =0;i<ROW;i++){
		for(int j = 0;j<COL;j++){
			
			array[i][j] = (rand() % 20)+1;
			
		}
	}
	
}

void arrayPrint(int array[][COL]){
	int sum = 0;
	int arr[4];
	int i,j;
	for(i=0; i<ROW; i++){
		printf("%4d �� : ",i);
		for(j = 0; j<COL; j++){
			printf("%3d",array[i][j]);
			sum += array[i][j];
			arr[j] += array[i][j];
		}

		printf("\trow sum = %d\n",sum);
		sum=0;
	}
	printf("col sum : %3d%3d%3d%3d ",arr[0],arr[1],arr[2],arr[3]);
}
	
