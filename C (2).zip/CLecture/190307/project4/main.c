#include <stdio.h>


int main() {
	int i;
	char msg[] = "Hello";
	for(i = 0; i<(sizeof(msg)/sizeof(msg[0])); ++i){
		printf("%c", msg[i]);
	}
	printf("\n");
	
	
	return 0;
}
