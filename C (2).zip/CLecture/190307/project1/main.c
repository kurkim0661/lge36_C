#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int Putin(int* in);
int calculate(int);
void taxcal(int);
void result(void);




int main() {
	
	int time = 0;
	int total = 0;
	int total_intax = 0;
	int tax = 0;
	time = Putin();
	total = calculate(time);
	taxcal(&total);
	return 0;
}

int Putin(void){
	int num;
	printf("�ٹ��ð��� �Է��ϼ���. : ");
	scanf("%d", &num);
	return num;
}
int calculate(int time){
	int total;
	
	if(time > 40){
		total += time*3000*1.5;
	}
	else{
		total +=(time*3000);
	}
	printf(""
	return total;
}
void taxcal(int *total){
	if(*total<100000){
		*total = (*total) * 0.85;
	}
	else{
		*total = (*total) * 0.75;
	}
}
