#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LEN 10

void BubbleSort(int A[], int size);

int main() {
	int i;
	int j;
	int test;
	int n;
	int k = 0;
	int *arr;
	int *arr2;
	freopen("data.txt","r",stdin);
	scanf("%d",&test);
	for(i=0;i<test;i++){
		scanf("%d",&n);
		printf("�˻��� ���� : ");
		arr = (int *)malloc(sizeof(int)*n);
		arr2 = (int *)malloc(sizeof(int)*n);
		for(j=0;j<n;j++){
			
			scanf("%d",&arr[j]);
			printf("%2d ",arr[j]);
		}
//		BubbleSort(arr,sizeof(arr)/sizeof(int));

		while(k!=n){
			if(abs(arr[k]-arr[k+1])<n){
				arr2[(arr[k]-arr[k+1])] = 1;	
			}
			else{
				printf("NOT JOLLY JUMP");
				break;
			}
			
			k++;
		}
		k=0;
		while(k!=n){
				
		}
		
		free(arr);
		free(arr2);
		printf("\n");
	}
	
	
	
	return 0;
}

void BubbleSort(int * A, int size)
{
	for(int i=0; i<size; i++)
	{
		for(int j=0; j<size-1; j++)
		{
			if( A[j] > A[j+1] )
			{
				int temp = A[j];
				A[j] = A[j+1];
				A[j+1] = temp;
			}
		}
	}
}
