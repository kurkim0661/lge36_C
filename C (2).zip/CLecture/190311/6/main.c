#include <stdio.h>
#include <stdlib.h>
#define CNT 2
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
typedef struct score{
	int kor;
	int eng;
	int math;
} Score;
int main(int argc, char *argv[]) {
	Score jumsu[]= {{90,90,80},{100,90,70}};
	print_score(jumsu);
	return 0;
}

void print_score(Score *ary){
	int i;
	for(i=0;i<CNT;i++){
	printf("KOR : %3d ENG : %3d MATH : %3d\n",(ary+i)->kor,(ary+i)->eng,ary[i].math);
	}	
}
