#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ROW 5
#define COL 20
#define LEN 20
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void Inputdata(char arr[][COL]);
void Sort(char A[][COL]);
void Out(char arr[][COL]);
void myflush(void);

int main() {
	char str[ROW][COL];
	Inputdata(str);
	Sort(str);
	Out(str);
	return 0;
}

void Inputdata(char arr[][COL]){
	int i = 0;
	char ch[LEN];
	while(1){
		printf("# %d�� ���ڿ��� �Է��Ͻÿ� : ",i+1);
		scanf("%s",	arr[i]);
		myflush();
		
		printf("\n");
		
		i++;
		if(i==5)break;
	}
}

void Out(char arr[][COL]){
	int i;
	int j;
	int len;
	for(i=0; i<ROW;i++){
			len = strlen(arr[i]);
			printf("str[0] =%s %c %c \n",arr[i],arr[i][0],arr[i][len-1]);
		
	}
}

void Sort(char A[][COL])
{
	char temp[COL];
	for(int i=0; i<ROW; i++)
	{
		for(int j=0; j<ROW-1; j++)
		{
			if((strcmp(A[j],A[j+1])>0 ))
			{
				strcpy(temp,A[j]);
				strcpy(A[j],A[j+1]);
				strcpy(A[j+1],temp);
			}
		}
	}
}

void myflush(void){
	while(getchar() !='\n');
}
