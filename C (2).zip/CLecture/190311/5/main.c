#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
struct{
	char name[50];
	unsigned char age;
}hong;
int main(int argc, char *argv[]) {
	
	printf("%s : %u",hong.name,hong.age);
	return 0;
}
