#include<stdio.h>
#include<malloc.h>
#include<string.h>
#define LINESIZE 100

int ** myAlloc(int, int);
void dataInput(int **, int, int);
void dataOutput(int **, int, int);
void myDelete(int **p, int row);
int main()
{
	int  **ip;
	int  col, row;
	printf("row �� �Է� : ");
	scanf("%d", &row);
	printf("column �� �Է� : ");
	scanf("%d", &col);
	ip = myAlloc(row, col);
	if (ip == NULL) {
		return 1;
	}
	dataInput(ip, row, col);
	dataOutput(ip, row, col);
	myDelete(ip, row);
	return 0;
}
int ** myAlloc(int row, int col){
	int i;
	int j;
	int **rp = NULL;
	
	rp = (int **)malloc(row*sizeof(int*));
	memset(rp, 0, sizeof(int*)*row);
		if(rp !=NULL){
		for(i=0;i<row;i++){
				
		}
			rp[i] = (int *)malloc(col * sizeof(int));
			if(rp[i] ==NULL){
				for(j=0;j<row;j++){
					free(rp[j]);
				}
				free(rp);
				rp = NULL;
			}
		}
		return rp;
	}


void dataOutput(int **p, int row, int col){
	int i;
	int j;
	
	for(i=0;i<row;i++){
		for(j=0;j<col;j++){
			printf("%d",p[row][col]);		
		}
	}
}

void dataInput(int **p, int row, int col){
	int i;
	int j;
	char readline[LINESIZE];
	int n;
	char *cp;
	
	if(p!=NULL){
		for(i = 0; i<row; i++){
			for(j =0;j<col; j++){
					while(1){
					printf("���� �Է� : ");
					fgets(readline,sizeof(readline),stdin);
					if(readline[strlen(readline) - 1] == '\n'){
						readline[strlen(readline) - 1] = '\0';
					}
					n =strtol(readline,&cp,10);
					if(*cp != '\0'){
						continue;
					}
					break;
					}
					p[i][j] = n;
			}
			
		}	
	}
}

void myDelete(int **p, int row){
	int i;
	for(i = 0; i<row; i++){
		free(p[i]);
		p[i] = NULL;
		
	}
	free(p);
}
