#include <stdio.h>
#include <stdlib.h>

typedef struct _house{
	char name[50];
	int howmany;
	struct _house *next;	
}house;

int main() {
	
	house myHome = {"ȫ�浿", 4, NULL};
	house yourHome = {"��û��",3,&myHome);
	house *cur;
	
	cur = &yourHome;
	printf("%s %d\n",cur->name,yourHome.howmany);
	cur = yourHome.next;
	printf("%s %d\n",cur->name,yourHome.next->howmany); 
	
	return 0;
}
