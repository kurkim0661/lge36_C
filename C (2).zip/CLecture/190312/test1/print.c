#include<stdio.h>

typedef void (*pfunc_t)(void *);

void printInt(void *p){
	printf("%d\n",*(int *)p);
void printDouble(void *p){
	double *dp = (double *)p;
	printf("%lf\n",*dp);	
}
void printChar(void *p){
	printf("%c\n",*(char *)p);	
}
void print(void *p,pfunc_t printFunc){
	printFunc(p);
}

int main(){
	int i =10;
	double d = 3.14;
	char c = 'A';
	
	print(&i, printInt);
	print(&d,printDouble);
	print(&c,printChar);
	
	return 0;
		
}
