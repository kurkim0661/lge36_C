#include <stdio.h>
#define MAX 1000000
int queue[MAX];
int front;
int rear;
int vertex[10000];
int edge[100000];
int visit[100000];
int check[100000];
int V;
int E;
int main() {
	int ver;
	int ed;
	int i;
	int j;
	int max = -1;
	int min = 100000;
	int flag = 0;
	
	int temp;
	scanf("%d %d",&V,&E);
	for(i=0;i<E;i++){
		scanf("%d %d",&vertex[i],&edge[i]);	
	}
	if(V ==1 ){
		printf("%d",0);
		return 0;
	}
	queue[rear++] = 0;
	for(i=0;i<E;i++){
		
	}
	while(front !=rear){
		temp = queue[front++];
		for(i=0;i<E;i++){
			if(vertex[i] == temp){
				queue[rear++] = edge[i];	
				visit[edge[i]] = visit[vertex[i]]+1;
				flag = 1;
			}
			else if(i == E-1 && flag == 0){
				check[temp] = 1;
				
			}
		}
		flag = 0;
	}
	
	for(i=1;i<=E;i++){
		if(max < visit[i] && check[i] == 1){
			max = visit[i];
		}
		if(min>visit[i] && check[i] == 1){
			min = visit[i];	
		}
	}
	printf("%d",max-min);
  return 0;
}

