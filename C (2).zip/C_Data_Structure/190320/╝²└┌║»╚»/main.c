#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
const char *big[] = {"��","��","��"};
const char *small[] = {"õ","��","��"};
const char *num[] = {"��","��","��","��","��","��","ĥ","��","��"}; 


int main() {
	char str[17];
	int size;
	int i;
	int j;
	int n;
	int pos;
	int quo;
	int rem;
	int sum = 0;
	scanf("%s",str);
//	printf("%s\n",str);
	size = strlen(str);
	quo = size/4;
	rem = size%4;
	pos = size;
//	printf("%d\n",size);
	
	for(i=0;i<size;i++){
		quo = (pos/4);
		rem = (pos%4);
		n = str[i]-48;
		if(pos%4 ==0){
			sum=0;	
		}
		sum+=n;
		for(j=1;j<=9;j++){
			if(n>0){
//				printf("%d ",n);
				if(n == j){
					printf("%s",num[j-1]);
					if((rem)!=1){
						if(rem == 0){
							printf("%s",small[0]);
						}
						else if(rem ==3){
							printf("%s",small[1]);
						}
						else{
							printf("%s",small[2]);
						}
					}
					if(quo>=1 && rem ==1){
						printf("%s",big[quo-1]);
					}
				}
			}
			else{
				if(quo>=1 && rem ==1){
					if(sum!=0){
						printf("%s",big[quo-1]);
					}
					
					break;
			}
			}	
		}
	pos--;	
	}
	
	
	return 0;	
}

