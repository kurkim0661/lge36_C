#ifndef BINARYSEARCH_H_
#define BINARYSEARCH_H_

/* �̺� �˻� �Լ� */
int binarySearch(int ary[], int size, int key);

#endif /* BINARYSEARCH_H_ */
