#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int num;
	int i;
	int arr[100];
	srand((unsigned int)time (NULL));
	for(i = 0 ;i<10;i++){
		arr[i] = random(20);
		for(int j=0;j<i;j++){
			if(ary[j] == ary[i]){
				i--;
				break;
			}
		}
		printf("%d ",arr[i]);
	}
	return 0;
}

int random(int n){
	int res;
	res = rnad() % n +1;
	
	return res;
}
