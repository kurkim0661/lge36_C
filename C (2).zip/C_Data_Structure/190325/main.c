#include <stdio.h>

int N;//���� ��
int T;//��å �ð�(�д���)
int P[100000 + 10];//���� ��� ��ġ
int S[100000 + 10];//���� ��å �ӵ�(�д�)
int size;

void sorting(void);
void Input_Data(void){
	int i;
	scanf("%d %d", &N, &T);
	for (i = 0; i < N; i++){
		scanf("%d %d", &P[i], &S[i]);
	}
}

int main(void){
	int i;
	int j;
	int cmp;
	int ans = 1;
	int temp;
	
	Input_Data();		//	�Է� �Լ�
	sorting();
	
	
	cmp = P[N-1] + S[N-1] * T;

	for(j=0;j<N;j++){
		temp = P[N-1-j] + S[N-1-j] *T;
		if(cmp > temp){
			ans++;
			cmp = P[N-1-j] + S[N-1-j] *T;
		}
	}
	
	printf("%d\n", ans);		//	���� ���
	return 0;
}

void sorting(void){
	int i;
	int j;
	int temp;
	
	for(j=0;j<N-1;j++){
		for(i=j;i<N-1;i++){
			if(P[i] > P[i+1]){
				temp = P[i];
				P[i] = P[i+1];
				P[i+1] = P[i];
				
				temp = S[i];
				S[i] = S[i+1];
				S[i+1] = S[i];
			}
		}
	}
}
