#include <stdio.h>
#include <stdlib.h>
#define BUFFER_SIZE 100
/* run this program using the console pauser or add your own getch, system("pause") or input loop */


int main(int argc, char *argv[]) {
	
	int T;
	int tc; //loop ī����
	int age;
	char nameBuffer[BUFFER_SIZE]= { 0 };
	
	
	freopen("data.txt","r",stdin);
	scanf("%d",&T);
	
	for(tc=0;tc<T;tc++){
		memset(nameBuffer,0,BUFFER_SIZE);
		scanf("%s",	nameBuffer);
		scanf("%d", &age);
		
		printf("�̸� : %s\n",nameBuffer);
		printf("���� : %d\n",age);
	}
	
	 
	return 0;
}
