#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "stack.h"
#define MAX 5

int main(void) {
	stack_t stack;
	int r;
	int i;
	srand((unsigned int)time(NULL));

//	createStack(&stack, MAX);
	if(createStack(&stack,MAX)==FALSE)return 1;
	printf("***** �Է°�  *****\n");
	for (i=0 ; i<(MAX+1) ; i++) {
		r = rand() % MAX + 1;
		printf("%d ", r);
		if (push(&stack, r) == TRUE) {
			printf("�Է¼���!!!\n");
		}
		else {
			printf("�Է½���!!!\n");
		}
	}

	printf("��°� : ");
	while (!isStackEmpty(&stack)) {
		if (pop(&stack, &r) == TRUE) {
			printf("%d ", r);
		}
	}
	printf("\n");
	destroyStack(&stack);
	return 0;
}
