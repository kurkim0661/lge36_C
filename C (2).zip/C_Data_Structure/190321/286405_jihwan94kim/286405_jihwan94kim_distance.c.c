#include <stdio.h>
#include <stdlib.h>
typedef enum _bool { FALSE, TRUE } bool_t;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */


int main() {
	
	int i;
	int j;
	int num1;
	int num2;
	int temp1;
	int temp2;
	int cnt1=0;
	int cnt2=0;	
	while(1){
		cnt1 = 0;
		cnt2 = 0;
	printf("#�γ�带 �Է��ϼ��� : ");
	
	scanf("%d %d",&num1,&num2);

	if(num1==0 ||num2 ==0){
		break;
	}
	temp1 = num1;
	temp2 = num2;

	
	
	while(temp1 != temp2){
	
		if(temp1>temp2){
			temp1 /= 2;
			cnt1++;
		}
		else if(temp1<temp2){
			temp2 /= 2;
			cnt2++;
		}
	}
	printf("�� ����� �Ÿ��� %d\n\n",cnt1 + cnt2);
	}
	

	
	
//	int i;
//	int j;
//	int num1;
//	int num2;
//	int max;
//	int data;
//	int temp1 = 1;
//	int temp2 = 2;
//	node_t *pp;
//	node_t *tp;
//	node_t *np;
//	queue_t queue;
//	tree_t tree;
//	initTree(&tree);
//	while(1){
//	
//	printf("#����ȣ 2���� �Է��Ͻÿ� : ");
//	scanf("%d %d",&num1,&num2);
//	printf("%d�� %d������ �Ÿ� : ",num1,num2); 
//	if(num1>num2){
//		max = num1;
//	}
//	else{
//		max = num2;
//	}
//	for(i=1;i<=max;i++){
//		addNode(&tree,i);
//	}
//
//	
//	tp = searchNode(&tree,num1);
//	np = searchNode(&tree,num2);
//	temp1 = tp->data;
//	temp2 = np->data;
//	while(temp1 != temp2){
//		if(tp->level > np->level){
//			temp1 = temp1/2;
//		}
//		else if(tp->level < np->level){
//			temp2 = temp2/2;
//		}
//		else{
//			temp1 = temp1/2;
//			temp2 = temp2/2;
//		}
//	}
//	pp = searchNode(&tree,temp1);
//	
//	temp2 = (tp->level-pp->level) + (np->level-pp->level);
//	
//	printf("%d\n",temp2);
//}
	return 0;
}
