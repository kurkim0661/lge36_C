#include <stdio.h>
#include "MaxPath.h"

int main(void) {
	freopen("data.txt", "r", stdin);

	initMap();
	
	createMap();
	
	printDir();
	printMap();
	printf("�ִ� �� : %d\n", calc());
//	printMap();
	
	printPath();

	return 0;
}
