#include <stdio.h>
#include "MaxPath.h"

int map[MAX + 1][MAX + 1];
int dir[MAX + 1][MAX + 1];
int N;
int map2[MAX +1][MAX + 1];
int stack[MAX*MAX];
int top;
int dx[] = {0,1,-1,0};
int dy[] = {1,0,0,-1};

void initMap(void) {
	int i;
	int j;
	scanf("%d",&N);
	
	for(i=0;i<N+1;i++){
		for(j=0;j<N+1;j++){
			map[i][j] = 0;
		}
	}

}

void createMap(void) {
	
	int i;
	int j;
	int max;
	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			scanf("%d",&dir[i][j]);
		}
	}
	
	for(i=1;i<N+1;i++){
		for(j=1;j<N+1;j++){
			if(map[i-1][j] > map[i][j-1]){
				map[i][j] = map[i-1][j]+dir[i-1][j-1];
				map2[i-1][j-1] = 1;
			}
			else if(map[i-1][j] < map[i][j-1]){
				map[i][j] = map[i][j-1]+dir[i-1][j-1];
				map2[i-1][j-1] = 2;
			}
			else{
				map[i][j] = map[i][j-1]+dir[i-1][j-1];
				map2[i-1][j-1] = 3;
			}
		}
	}

}

void printMap(void) {
	int i;
	int j;

	for (i=1 ; i<=N ; i++) {
		for (j=1 ; j<=N ; j++) {
			printf("%3d", map[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

void printDir(void) {
	int i;
	int j;
	
	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			printf("%d ",dir[i][j]);
		}
	 printf("\n");
	}
	printf("\n\n");
}

int calc(void) {

	return map[N][N];
}

void printPath(void) {
	int i = N;
	int j =N;
	
	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			printf("%d ",map2[i][j]);
		}
		printf("\n");
	
	}
	i = N;
	j = N;
	while(map[i][j] !=0){
		stack[top++]=map[i][j];
		if(map[i][j] == 1){
			i--;
		}
		else{
			j--;
		}
	}
	while(top!=0){
		printf("%d > ",stack[--top]);
	}
return ;
}
	

