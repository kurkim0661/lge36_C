#include <stdio.h>
#include "KnapSack.h"

int dp[MAX + 1][MAX + 1];
int V[MAX + 1];
int W[MAX + 1];
int C;
int J;
int N;
void initData(void) {

	int i;
	int j;
	for(i=0;i<N;i++){
		scanf("%d %d",&W[i],&V[i]);
	}
	
	for(i=1;i<=N;i++){
		for(j=1;j<=J;j++){
			if(W[i] > J){
				dp[i][j] = dp[i-1][j];
			}
			else{
				if(dp[i-1][j] >dp[i-1][j-W[i]] +V[i]){
					dp[i][j] = dp[i-1][j];
				}
				else{
					dp[i][j] = dp[i-1][j-W[i]] +V[i];
				}
			}
		}
	}
	
		
}

void createData(void) {

	

}

void printData(void) {
	int i;

	for (i=1 ; i<=J ; i++) {
		printf("%d %d\n", W[i], V[i]);
	}
}

int calc(void) {

	/*
	 * TO DO
	 */

	return 0;
}
