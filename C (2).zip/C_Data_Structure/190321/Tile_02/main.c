#include <stdio.h>

int f(int n);

int main(void) {
	int T;
	int n;
	int tc;

	freopen("data.txt", "r", stdin);
	scanf("%d", &T);
	for (tc=0 ; tc<T ; tc++) {
		scanf("%d", &n);
		int m = f(n);
		printf("%d\n", m);
	}
	
	return 0;
}

int f(int n) {
	int i;
	int temp = 1;
	for(i=1;i<n;i++){
		if(i%2 == 1){
		temp = 2*temp+1;
		}
		else{
		temp = 2*temp-1;
		}	
	}
	
	return temp;
}
