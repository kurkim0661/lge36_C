#include <stdio.h>
#include <stdlib.h>
#define ROW 10
#define COL 10
/* run this program using the console pauser or add your own getch, system("pause") or input loop */



int main(int argc, char *argv[]) {
	int crow;
	int ccol;
	int inrow;
	int incol;
	int i;
	int j;
	int k;
	int l;
	int temp;
	int max = 0;
	int city[ROW][COL];
	freopen("array1_data.txt","r",stdin);
	scanf("%d %d %d %d",&crow,&ccol,&inrow,&incol);
	
	for(i=0;i<crow;i++){
		for(j=0;j<ccol;j++){
			scanf("%d",&city[i][j]);
			printf("%2d",city[i][j]);
		}
		printf("\n");
	}
	
	for(i=0;i<(crow-inrow);i++){
		for(j=0;j<(ccol-incol);j++){
			temp = 0;
			for(k=0; k<inrow;k++){
				for(l=0; l<incol;l++){
					temp +=city[i+k][j+l];
				}
			}
		}
		if(temp>max){
			max = temp;
		}
	}
	
	printf("�ִ� �α� �е� : %d",max);
	return 0;
	
}
