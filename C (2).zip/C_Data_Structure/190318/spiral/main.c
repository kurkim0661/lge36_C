#include <stdio.h>
#include <stdlib.h>
#define MAX 10
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int N;
	int i;
	int j;
	int t;
	int r;
	int b;
	int l;
	int arr[MAX][MAX];
	int num = 1;
	scanf("%d",&N);
	
	for(i=0;i<N/2;i++){
		for(t=i;t<N-i-1;t++){
			arr[i][t] = num++;	
		}
		for(r=i;r<N-i-1;r++){
			arr[r][N-i-1] = num++;
		}
		for(b=N-i-1;b>i;b--){
			arr[N-i-1][b] = num++;
		}
		for(l=N-i-1;l>i;l--){
			arr[l][i]=num++;
		}
	}
	if(N%2==1){
		arr[N/2][N/2] = num;
	}
	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			printf(" %2d ",arr[i][j]);
		}
		printf("\n");
	}
	return 0;
}
