#include <stdio.h>
#include "Graph.h"

int main(void) {
	graph_t grp;

	freopen("data.txt", "r", stdin);

	initGraph(&grp);
	outputGraph(&grp);
	destroyGraph(&grp);

	return 0;
}
