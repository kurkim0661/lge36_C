BFS(graph_t *gp, int s){
	int v;
	node_t *cur;
	
	if(gp==NULL){
		return ;
	}
	
	queue[rear++]=s;
	visited[s] = 1;
	
	while(front !=rear){
		v=queue[front++];
		printf("%2c",v+'A');
		
		cur = gp->graph[v];
		while(cur!=NULL){
			if(visited[cur->vertex] == 0){
				queue[rear++] = cur->vertex;
				visited[cur=>vertex] =1;
			}
			cur= cur->next;
		}
	}
}
