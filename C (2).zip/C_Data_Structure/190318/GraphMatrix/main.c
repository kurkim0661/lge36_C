#include <stdio.h>
#include "Graph.h"

int main(void) {
	
	
	freopen("data.txt", "r", stdin);
	scanf("%d %d", &vertex, &edge);
	initGraph();
	createGraph();
	printf("-----------------------------------------\n");
	printf("                 ��������Ʈ\n");
 	printf("-----------------------------------------\n");
	printGraph();
	printf("-----------------------------------------\n");
	printf("           ������� DFS�湮\n");
 	printf("-----------------------------------------\n");
 	startBFS();
 	printf("��ü �׷����� �� : %d\n",cnt);
	

	return 0;
}
