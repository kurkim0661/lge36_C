#include <stdio.h>
#include <stdlib.h>
#define MAX 9
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int N;
	int i;
	int j;
	int arr[MAX][MAX] = {0};
	int num = 1;
	scanf("%d",&N);
	
	for(i=0;i<N;i++){
		for(j=0;j<(N-i);j++){
			arr[j][i+j] = num++;
		}
	}
	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			printf("%2d ",arr[i][j]);
		}
		printf("\n");
	}
	return 0;
}
