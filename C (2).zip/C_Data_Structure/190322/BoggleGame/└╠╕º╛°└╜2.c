#include <stdio.h>
#define MAX 1000000

int Q[MAX + 1];
int V[MAX + 1];
int front;
int rear;
int D[] = { -1, 1, 5, 10 };

void bfs(int n, int k, int m) {
	int i;
	int u;
	int v;

	for (i=0 ; i<(MAX+1) ; i++) {
		Q[i] = 0;
		V[i] = 0;
	}
	front = 0;
	rear = 0;

	Q[rear++] = n;
	V[n] = 0;

	while (front != rear) {
		u = Q[front++];
		if (u == m) {
			break;
		}
		else {
			for (i=0 ; i<(sizeof(D) / sizeof(D[0])) ; i++) {
				v = u + D[i];
				if ((v > 0) && (v <= k) && (v != n) && (V[v] == 0)) {
					V[v] = V[u] + 1;
					Q[rear++] = v;
				}
			}
		}
	}
}

int main(void) {
	int T;
	int tc;
	int s;
	int e;

	freopen("data.txt", "r", stdin);
	scanf("%d", &T);
	for (tc=0 ; tc<T ; tc++) {
		scanf("%d %d", &s, &e);
		bfs(s, MAX, e);
		printf("%d\n", V[e]);
	}
	return 0;
}
