#include <stdio.h>
#include "nqueen.h"

check_t columnChk[MAX_CNT + 1];					/* �÷� üũ �迭 */
check_t incDiagonalLineChk[(MAX_CNT * 2) + 1];	/* �밢�� üũ */
check_t decDiagonalLineChk[(MAX_CNT * 2) + 1];	/* �밢�� üũ */
int placementCnt;								/* ��ġ ���� �� ī���� */
int N;											/* üũ�ǰ� ���� �� */


void initCheck(void) {
	
	int i;
	int j;
	for(i=1;i<=N;i++){
		nQueen(i);
	}
}

void nQueen(int row) {
	int i;
	
	columnChk[row];
	incDiagonalLineChk[row];
	decDiagonalLineChk[row];
	nQueen(row + 1);
	
	return;
	
	for(i=1;i<=N;i++){
		columnChk[]
		incDiagonalLineChk[i];
		decDiagonalLineChk[i];
	}
}
