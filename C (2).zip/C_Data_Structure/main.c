#include <stdio.h>
#include <string.h>
#define MAX_N 50000
#define MAX_M 1000
#define MAX_Length 100

char N[MAX_N];
int num = MAX_M;
char Length[MAX_Length];
int cnt[MAX_N];
char str[MAX_M][MAX_Length];

int main() {
	int i;
	int j;
	int k;
	int maxV=0;
	int size_N;
	int size_Length;
	char temp[MAX_Length];
	int temp2;
	
	scanf("%s",N);
	scanf("%d",&num);
	
	size_N = strlen(N);
	
	for(i=0;i<num;i++){
		scanf("%s",str[i]);
		
		size_Length = strlen(str[i]);
		for(j=0;j<size_N-size_Length+1;j++){
			for(k=0;k<size_Length;k++){
				temp[k] = N[k+j];	
			}
			temp[size_Length] = '\0';
			if(strcmp(temp,str[i])==0){
				cnt[i]++;
			}
		}
	}
	
	for(i=0;i<num;i++){
		if(maxV < cnt[i]){
			maxV = cnt[i];
			temp2 = i;	
		}
	}
	if(maxV != 0){
	printf("%s",str[temp2]);
	}
	else{
		printf("null");	
	}
	
  return 0;
}

