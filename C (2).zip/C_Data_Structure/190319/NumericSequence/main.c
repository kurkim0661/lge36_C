#include <stdio.h>
#define MAX 10

int L[MAX];

void printArray(int arr);
void f(int n, int k) {

	if(n==k){
		printArray(L);
		return ;
	}
	else{
		for(int i=3; i>0; i--){
			L[n] = i;
			f(n+1,k);
		}
	}
}

int main(void) {
	f(0, 3);
	return 0;
}

void printArray(int arr){
	for(int i =0; i<3;i++){
		printf("%2d ",L[i]);
	}
	printf("\n");
}
