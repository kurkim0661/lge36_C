#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int i=0;
int sub(int,int,int);
int L[] = {3,7,6,2,1,4,8,5};

int main() {
	sub(0,5,9);
	return 0;
}

int sub(int n,int k, int v){
	if(n==k){
		printf("�˻�����\n");
		return 0; 
	}
	else if(L[n] == v){
		return 1;
	}
	else{
		return sub(n+1,k,v);
	}
}
