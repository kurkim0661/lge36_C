#include <stdio.h>
#include <stdlib.h>
#define MAX 10

int perm[MAX];
int used[MAX];
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int N;
int K;
int A[MAX][MAX];
int minV;
int best[MAX];
int minV = MAX * MAX;
void createPerm(int n, int k);


int main() {
	int m=0;
	freopen("data.txt", "r", stdin);
	scanf("%d ",&N);
	while(m!=3){
	scanf("%d",&K);
	N=K;
	
	for (int i=1 ; i<=N ; i++) {
		for(int j=1; j<=K; j++){
			scanf("%d",&A[i][j]);
		}
	}
	
	createPerm(0,K);
	
	printf("�ִܰŸ� : %d\n", minV);
	printf("���� > ");
	for (int i=0 ; i<K ; i++) {
		printf("%d > ", best[i]);
	}
	printf("���õ���\n");
	m++;
	minV=MAX*MAX;
	}
	
	
	
	return 0;
}


void createPerm(int n, int k) {
	int i;
	int j;
	int temp = 0;
	int sum = 0;
	if(n == k){
		for(j=1;j<=K;j++){
			sum += A[j][perm[j]];
//			temp = perm[j];
		}
		if(sum < minV ){
			for(i = 0; i<K; i++){
				best[i] = perm[i+1];
			}
			minV = sum;
		}
		return;
	}
	else{
		for(i =1; i<=k; i++){
			if(used[i] == 0){
				used[i] = 1;
				perm[n+1] = i;
				createPerm(n+1,k);
				used[i] = 0;
			}
			
		}
	}
	

}
