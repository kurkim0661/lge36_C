#include <stdio.h>
#define MAX 10

int a[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
int L[MAX];
int used[MAX];

void printArray(int arr){
	for(int i =0; i<3;i++){
		printf("%2d ",L[i]);
	}
	printf("\n");
}

void f(int n, int k) {

	if(n==k){
		printArray(f);
		return ;
	}
	else{
		for(int i =0; i<3;i++){
			if(used[i]==0){
				used[i] = 1;
				L[n] = a[i];
				f(n+1,k);
				used[i]=0;
			}
			
		}
	}

}

int main(void) {
	f(0, 3);
	return 0;
}
