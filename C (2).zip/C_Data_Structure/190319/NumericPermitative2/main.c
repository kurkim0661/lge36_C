#include <stdio.h>
#define MAX 10

int a[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
int L[MAX];
int used[MAX];
int cnt;
void printArray(int arr){
	for(int i =0; i<3;i++){
		printf("%2d ",L[i]);
	}
	printf("\n");
}

void f(int n, int k, int m) {
	
	if(n==m){
		cnt++;
		printArray(f);
		return ;	
	}
	else{
		for(int i=0; i<k; i++){
			if(used[i] ==0){
			used[i] = 1;
			L[n] = i+1;
			f(n+1,k,m);
			used[i]=0;	
			}
			
		}
	}

}

int main(void) {
	f(0, 5, 3);
	printf("�� ���� ȸ�� : %d\n", cnt);
	return 0;
}
