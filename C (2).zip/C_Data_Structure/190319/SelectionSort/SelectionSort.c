#include <stdio.h>
#include <stdlib.h>
#include "SelectionSort.h"

void initArray(int *ary, int n) {

	int i;
	for(i = 0 ; i<n; i++){
		ary[i] = rand()%20 +1;
	}

}

void printArray(int *ary, int n) {

	int i;
	printf("�迭 ����: ");
	for(i=0;i<n;i++){
		printf("%d ",ary[i]);
	}
	printf("\n");
}

/*----------------------------------------------------------------
Function Name 	: selectionSort() - �������� �Լ�
Argument 		: ary - ���� ������ ���� �迭
 	 	 	 	  n - �迭 ������ ��
Return			: ����
-----------------------------------------------------------------*/
void selectionSort(int *ary, int n) {
	int i;
	int j;
	int temp;
	int minIdx;
	
	
	for(i=0;i<(n-1);i++){
		minIdx = i;
		for(j=i+1;j<n;j++){
			if(ary[minIdx] > ary[j]){
			minIdx = j;
			}
		}
	temp = ary[i];
	ary[i] = ary[minIdx];
	ary[minIdx] = temp;
	}
}
	
	

