#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"

int main(void){
	char text;
	node_t cursor;
	list_t editor;
	createList(&editor);
	char select;
	int num;
	
	
	while(1){
		createList(&editor);
		addFirst(&editor, 'a');
		addFirst(&editor, 'b');
		addFirst(&editor, 'c');
		addFirst(&editor, 'd');
		displayList(&editor);
		
		scanf("%d",&num);
		while(getchar() != '\n');
		for(int i =0; i<num;i++){
		
			scanf("%c", &select);
			if(select !='P')while(getchar() != '\n');
			switch(select){
				case 'L':
					moveLeft(&editor);
					break;
				case 'D':
					moveRight(&editor);
					break;
				case 'B':
					removeNode(&editor);
					break;
				case 'P':
					scanf("%c",&text);
					while(getchar() != '\n');
					addFirst(&editor,text);
					break;
				default :
					printf("---------\n");
					break;
			}
		}
		displayList(&editor);
		destoryList(&editor);
	}
	
//	while(getchar()!='\0'){
//		scanf("%c",text[]);
//	}
//	text = (char *)malloc(sizeof(text));
//	printf("%s",text);
	
	return 0;
}	
