#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "Queue.h"


int main(void) {
	int r;
	int i;
	int j = 0;
	queue_t que;
	int num1;
	int num2;
	int a[5000] = {0};
	int temp;
	srand((unsigned int)time(NULL));
	
	while(1){
		printf("# N(�ο���)�� M(���ݼ�)�� �Է��Ͻÿ� (M <= N) : ");
		scanf("%d %d",&num1,&num2);
		if(num1 < num2){
			printf("M�� N�� �Ѿ����ϴ�.\n\n"); 
			continue;
		}
		createQueue(&que, num1+1);
		printf("(%d, %d) �似Ǫ�� ���� : ",num1,num2);
	for(i = 0; i < num1;i++){
		enqueue(&que,i+1);
	}
	while(que.front != que.rear){
		dequeue(&que,&temp);
		j++;
		if(j==num2){
			printf("%2d  ",temp);	
				
			j=0;
		}
		else{
			enqueue(&que,temp);
		}
		
	}
	printf("\n");
  	
    
	
//	destroyQueue(&que);
	
	
	}
	
	return 0;
}
